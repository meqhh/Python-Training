<div align="center">
    <img src="https://cdn.iconscout.com/icon/free/png-256/free-python-logo-icon-download-in-svg-png-gif-file-formats--technology-social-media-vol-5-pack-logos-icons-2945099.png?f=webp&w=100" alt="Centered Image">
    <h1>Kanjut Package</h1>
</div>
<div>
    <b>Matematika Basic python tapi bahasa indo</b>
    <p>Berikut berapa penggunaan yang ada untuk versi 0.0.1 (maaf cuman segini dulu, ga sabar coba publish hehe)</p>
    <p>from kanjutmath import math</p>
    <ol type="1">
        <li>
            <b>penjumlahan()</b>
        </li>
        <ul>
            <p>Penjumlahan biasa tapi bisa lebih dari 2 isi dari parameter (11 / 12 sama sum() sih tapi yaudah)</p>
            <b>math.penjumlahan(1, 2, 3) #output = 6</b>
            <p></p>
        </ul>
        <li>
            <b>pengurangan()</b>
        </li>
        <ul>
            <p>Pengurangan biasa tapi bisa lebih dari 2 isi dari parameter</p>
            <b>math.pengurangan(10, 3, 2) #output = 5</b>
            <p></p>
        </ul>
        <li>
            <b>perkalian()</b>
        </li>
        <ul>
            <p>Perkalian yang kayak biasa doang sih tapi kalo mau kali-kalian yang banyak bisa aee</p>
            <b>math.perkalian(5, 5, 2) #output = 50</b>
            <p></p>
        </ul>
        <li>
            <b>pembagian()</b>
        </li>
        <ul>
            <p>Pembagian biasa doang tapi ya sama kayak sebelum-sebelumnya bisa lebih dari 2 parameter</p>
            <b>math.pembagian(30, 3, 2) #output = 5</b>
            <p></p>
        </ul>
        <li>
            <b>ganjilgenap()</b>
        </li>
        <ul>
            <p>Cuman pencari ganjil genap, tapi returnnya string ganjil ato genap doang bukan Boolean</p>
            <b>math.ganjilgenap(2, 3) #output = 2 adalah Genap, 3 adalah Ganjil</b>
            <p></p>
        </ul>        
        <li>
            <b>pangkat()</b>
        </li>
        <ul>
            <p>Perpangkatan doang udah itu aja tapi limit parameter cuman 2 doang tod</p>
            <b>math.pangkat(10, 3) #output = 1000</b>
            <p></p>
        </ul>
    </ol>
</div>